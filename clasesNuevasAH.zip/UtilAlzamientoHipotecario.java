package cl.sinacofi.ah;

import cl.sinacofi.cr.TextoMensaje;
import cl.sinacofi.db.ConnectDB;

/**
 * @author Jonathan Arce
 * @date 01-09-2023
 * @desc Clase encargada de retornar el valor de un campo de un mensaje.
 * @version 1.0
 *
 **/
public class UtilAlzamientoHipotecario {

	/**
	 * Entrega el valor de fecha y numero de NSE de la AH que viene en el texto del
	 * mensaje
	 *
	 * @param cod_mens, código del mensaje de la AH
	 * @param txt_mens, texto del mensaje donde se buscarán los valores en formato
	 *                  Tandem
	 * @param pool,     objeto con conexión a la BD
	 *
	 * @return String[], [0]=valor fecha NSE en formato AAAAMMDD [1]=valor del
	 *         correlativo NSE En caso de error, en la posición [0] es igual a "NK"
	 */
	public String[] getFechaNumNSE(String cod_mens, String txt_mens, ConnectDB pool) {
		String[] retorno = { "NK", "" };

		try {
			String cod_camp  = MessageAHCtes.getNombreCampo( cod_mens, "fec_y_nse" );
			String arreglo[] = TextoMensaje.getValorCampo(pool, txt_mens, cod_camp, 2);

			retorno[1] = arreglo[1]; // correlativo NSE
			retorno[0] = arreglo[0]; // fecha NSE en formato DDMMAAAA

			retorno[0] = retorno[0].substring(4, 8) + retorno[0].substring(2, 4) + retorno[0].substring(0, 2);
		} catch (Exception e) {
		}
		return retorno;
	}

	
}

package cl.sinacofi.ah;

import cl.sinacofi.db.ConnectDB;

/**
 * @author  Marco Ugarte C.
 * @date    05-09-2023
 * @desc    Esta interfaz representa la abstraccion de las operaciones
 *          de registro sobre las tablas de la base de seguimiento
 *          para los mensajes de Alzamiento hipotecario.
 * @version 1.0
**/
public interface MessageAH {
	
	/**
	 * Metodo encargado de ingresar un registro en la tabla tblDetSeguimiento.
	 * @return boolean, true si es un ingreso exitoso y false en caso contrario.
	**/
	
	public boolean ingRegistro(ConnectDB pool);	


public boolean esAH();
}

package cl.sinacofi.ah;

import cl.sinacofi.db.ConnectDB;
import cl.sinacofi.ah.MessageAH;
import cl.sinacofi.aut_distr.server.*;
import cl.sinacofi.cr.Op_tbl_dseg;
import cl.sinacofi.cr.Op_tbl_segu;

/**
 * @author  Marco ugarte C.
 * @date    05-09-2023
 * @desc    Clase encargada de realizar operaciones sobre detalle.
 * @version 1.0
 **/ 
public class MessageAHDetail implements MessageAH {
	  private String m_cod_mens = ""; //C�digo del mensaje
	  private String m_cod_tido = ""; //C�digo del Tid origen
	  private String m_cod_tidd = ""; //C�digo del Tid destino
	  private String m_num_nnse = ""; //N�mero nse de envio del mensaje CR
	  private String m_fec_nnse = ""; //Fecha nse de envio del mensaje CR
	  private String m_hor_nnse = ""; //Hora nse de envio del mensaje CR
	  private String m_num_rnse = ""; //N�mero nse del mensaje recibido
	  private String m_fec_rnse = ""; //Fecha nse del mensaje recibido
	  private String m_hor_rnse = ""; //Hora nse del mensaje recibido
	  private String m_num_rosn = ""; //N�mero osn del mensaje recibido
	  private String m_fec_rosn = ""; //Fecha osn del mensaje recibido
	  private String m_hor_rosn = ""; //Hora osn del mensaje recibido
	  private String m_des_oper = ""; //Descripción del estado del mensaje en seguimiento
	  private String m_cod_oper = ""; //C�digo del estado del mensaje en seguimiento
	  private String x_cod_camp = ""; //C�digo del campo en que se encuentra el numero y fecha nsr
	  private String x_txt_mens = ""; //Texto del mensaje recibido
	  private boolean m_estado = false;  //Indica si hay algun error en el constructor
	  private String m_camp_CVR = "";
	  private String m_camp_CVS = "";
	  private String m_camp_CVT = "";
	  private String m_camp_CVU = "";
	  private String m_camp_CVZ = "";
	  private String m_camp_CW1 = "";
	  private String m_camp_LS8 = "";
	  private String m_camp_CVL = "";
	  private String m_camp_Rechazo = "";

	  /**
	   * Metodo encargado de ingresar un registro en la tabla tblDetSeguimientoAH.
	   * @return boolean, true si es un ingreso exitoso y false en caso contrario.
	   */
	public boolean ingRegistro(ConnectDB pool) {
		boolean registro = false;
		OpTblDetSeguimientoAH otd = new OpTblDetSeguimientoAH(m_cod_tido, m_cod_tidd, m_fec_nnse, m_hor_nnse, m_num_nnse, m_des_oper, m_cod_oper,
	                                      m_fec_rnse, m_hor_rnse, m_num_rnse, m_fec_rosn, m_hor_rosn, m_num_rosn);

	    if ( otd.ingRecepcion(pool) ) {
	    	OpTblSeguimientoAH ots = new OpTblSeguimientoAH(m_cod_tido, m_cod_tidd, m_fec_nnse, m_num_nnse);
	    	  registro = ots.actualizaRegistroMontos(pool, m_cod_tido, m_cod_tidd, m_fec_nnse, m_hor_nnse, m_num_nnse, m_camp_CVR,
	    	                                         m_camp_CVS, m_camp_CVT, m_camp_CVU, m_camp_CVZ, m_camp_CW1, m_camp_LS8, m_camp_CVL,
	    	                                         m_camp_Rechazo, m_cod_mens);
	    }
	    
	    return registro;
	}

	
	/**
	   * Metodo encargado de resolver si se trata de un mensaje Carta Resguardo o no.
	   * Los mensajes Carta Resguardo son: 630, 633, 636 y 639.
	   * @return boolean, true si es un mensaje Carta Resguardo, false en caso contrario.
	   */
	public boolean esAH() {
		 if (("630.633.636.639").indexOf(m_cod_mens)>=0)
		      return true;
		    else
		      return false;
	}

}

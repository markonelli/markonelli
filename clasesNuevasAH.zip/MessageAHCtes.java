package cl.sinacofi.ah;

import cl.sinacofi.db.ConnectDB;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.Vector;
import cl.sinacofi.mensaje.MensajeRecibido;
import cl.sinacofi.cr.hist.Op_tbl_hems;
import cl.sinacofi.gui.UtilCartaResguardo;

/**
 * @author Jonathan Arce
 * @date 05-09-2023
 * @desc Clase encargada de retornar el valor de un campo de un mensaje.
 * @version 1.0
 *
 **/

public class MessageAHCtes {

	/**
	 * Retorna el código del campo asociado al código de mensaje otorgado de acuerdo
	 * a la descripción solicitada: rut o nombre de vendedor, comprador y deudor.
	 * param cod_mens Código del mensaje. param des_camp Descripción del mensaje del
	 * cual se consulta. param mr Mensaje recibido.
	 * 
	 * @return String, Código del mensaje.
	 */

	public static final String des_oper_01 = "PERSONAS"; // Descripcion operacion 01, Personsas
	public static final String des_oper_02 = "INMOBILIARIAS"; // Descripcion operacion 02, Inmobiliarias
	public static final String cod_oper_01 = "01"; // Tipo operacion 01, Personsas
	public static final String cod_oper_02 = "02"; // Tipo operacion 02, Inmobiliarias

	public static String getNombreCampo(String cod_mens, String des_camp, MensajeRecibido mr, ConnectDB pool) {
		String cod_camp = "";
		String fec_prep = "";
		String tipBus = "1";
		Vector vent = new Vector();
		int fin = 20050810;
		try {
			UtilCartaResguardo ucr = new UtilCartaResguardo();
			String datMsgPrep[] = ucr.buscaFechayHoraPrep(mr.getCodTidO(), mr.getCodTidd(), mr.getFecNNse(),
					mr.getHorNNse(), mr.getNumCNse(), pool);
			if (datMsgPrep != null) {
				fec_prep = datMsgPrep[0];
				Op_tbl_hems hm = new Op_tbl_hems();
				vent = hm.getVentTiempoMS(cod_mens, fec_prep, tipBus, pool);
				if (vent.isEmpty()) {
					cod_camp = getNombreCampo_001(cod_mens, des_camp);
				} else {
					String fec1 = (String) vent.get(0);
					String hor1 = (String) vent.get(1);
					String fec2 = (String) vent.get(2);
					String hor2 = (String) vent.get(3);
					if (Integer.parseInt(fec1) > Integer.parseInt(fec_prep)
							&& Integer.parseInt(fec_prep) < Integer.parseInt(fec2)) {
						cod_camp = getNombreCampo_001(cod_mens, des_camp);
					} else {
						cod_camp = getNombreCampo_002(cod_mens, des_camp);
					}
				}
			}
		} catch (Exception ex) {
			System.out.println("Problemas en metodo getNombreCampo(): " + ex.getMessage());
			ex.printStackTrace();
		}
		return cod_camp;
	}

	/**
	 * Retorna el código del campo asociado al código de mensaje otorgado de acuerdo
	 * a la descripción solicitada: rut o nombre de vendedor, comprador y deudor.
	 * param cod_mens Código del mensaje. param des_camp Descripción del mensaje del
	 * cual se consulta.
	 * 
	 * @return String, Código del mensaje.
	 */
	public static String getNombreCampo_001(String cod_mens, String des_camp) {
		String cod_campo = "";
		try {
			if (des_camp.equals("rut_deud")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CS2";
				}
			} else {
				if (des_camp.equals("nom_comp")) {
					if (("630.633").indexOf(cod_mens) >= 0) {
						cod_campo = "CS1";
					} else {
						if (("636.639").indexOf(cod_mens) >= 0) {
							cod_campo = "CS4";
						}
					}
				}
			}
		} catch (Exception ex) {
			System.out.println("Problemas en metodo getNombreCampo_001()->" + ex.getMessage());
			ex.printStackTrace();
		}
		return cod_campo;
	}

	/**
	 * Retorna el código del campo asociado al código de mensaje otorgado de acuerdo
	 * a la descripción solicitada: rut o nombre de vendedor, comprador y deudor.
	 * param cod_mens Código del mensaje. param des_camp Descripción del mensaje del
	 * cual se consulta.
	 * 
	 * @return String, Código del mensaje.
	 */
	public static String getNombreCampo_002(String cod_mens, String des_camp) {
		String cod_campo = "";
		try {
			if (des_camp.equals("rut_vend")) {
				if (("630.633").indexOf(cod_mens) >= 0) {
					cod_campo = "CS2";
				}
			} else if (des_camp.equals("nom_vend")) {
				if (("630.633").indexOf(cod_mens) >= 0) {
					cod_campo = "CS1";
				}
			} else if (des_camp.equals("rut_comp")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CW5";
				}
			} else if (des_camp.equals("nom_comp")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CS4";
				}
			} else if (des_camp.equals("rut_deud")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CW3";
				}
			} else if (des_camp.equals("nom_deud")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "E32";
				}
			}

		} catch (Exception ex) {
			System.out.println("Problemas en metodo getNombreCampo_002()->" + ex.getMessage());
			ex.printStackTrace();
		}

		return cod_campo;
	}

	/**
	 * Retorna el código del campo asociado al código de mensaje otorgado de acuerdo
	 * a la descripción solicitada: fec_y_nse. param cod_mens Código del mensaje.
	 * param des_camp Descripción del mensaje del cual se consulta.
	 * 
	 * @return String, Código del mensaje.
	 */
	public static String getNombreCampo(String cod_mens, String des_camp) {
		String cod_campo = "";

		try {
			if (des_camp.equals("fec_y_nse")) {
				if (("671").indexOf(cod_mens) >= 0) {
					cod_campo = "SGV";
				} else {
					if (("632.635.638.641").indexOf(cod_mens) >= 0) {
						cod_campo = "CUO";
					} else {
						if (("674.675").indexOf(cod_mens) >= 0) {
							cod_campo = "SH8";
						}
					}
				}
			} else {
				if (des_camp.equals("cod_inte")) {
					if (("630.633.636.639").indexOf(cod_mens) >= 0) {
						cod_campo = "CUK";
					}
				} else {
					if (des_camp.equals("cod_oper")) {
						if (("630.631.632.633.634.635.636.637.638.639.640.641.642.643.644.645.646.647.648.649")
								.indexOf(cod_mens) >= 0) {
							cod_campo = "CW7";
						}
					}
				}
			}
			if (des_camp.equals("region_origen")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641.642.643.644.645.646.647.648.649")
						.indexOf(cod_mens) >= 0) {
					cod_campo = "CTF";
				}
			} else if (des_camp.equals("comuna_origen")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641.642.643.644.645.646.647.648.649")
						.indexOf(cod_mens) >= 0) {
					cod_campo = "CTG";
				}
			} else if (des_camp.equals("region_destino")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641.642.643.644.645.646.647.648.649")
						.indexOf(cod_mens) >= 0) {
					cod_campo = "CTI";
				}
			} else if (des_camp.equals("comuna_destino")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641.642.643.644.645.646.647.648.649")
						.indexOf(cod_mens) >= 0) {
					cod_campo = "CTJ";
				}
			} else if (des_camp.equals("monto_csd")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641").indexOf(cod_mens) >= 0) {
					cod_campo = "CSD";
				}
			} else if (des_camp.equals("monto_csf")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641").indexOf(cod_mens) >= 0) {
					cod_campo = "CSF";
				}
			} else if (des_camp.equals("monto_csk")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641").indexOf(cod_mens) >= 0) {
					cod_campo = "CSK";
				}
			} else if (des_camp.equals("monto_cso")) {
				if (("630.631.632.633.634.635.636.637.638.639.640.641").indexOf(cod_mens) >= 0) {
					cod_campo = "CSO";
				}
			} else if (des_camp.equals("monto_cuc")) {
				if (("633.634.635.639.640.641").indexOf(cod_mens) >= 0) {
					cod_campo = "CUC";
				}
			} else if (des_camp.equals("monto_cvr")) {
				if (("646.647.648.649").indexOf(cod_mens) >= 0) {
					cod_campo = "CVR";
				}
			} else if (des_camp.equals("monto_cvs")) {
				if (("646.647.648.649").indexOf(cod_mens) >= 0) {
					cod_campo = "CVS";
				}
			} else if (des_camp.equals("monto_cvt")) {
				if (("646.647.648.649").indexOf(cod_mens) >= 0) {
					cod_campo = "CVT";
				}
			} else if (des_camp.equals("monto_cvu")) {
				if (("646.647.648.649").indexOf(cod_mens) >= 0) {
					cod_campo = "CVU";
				}
			} else if (des_camp.equals("monto_cvz")) {
				if (("646.647").indexOf(cod_mens) >= 0) {
					cod_campo = "CVZ";
				}
			} else if (des_camp.equals("monto_cw1")) {
				if (("646.647").indexOf(cod_mens) >= 0) {
					cod_campo = "CW1";
				}
			} else if (des_camp.equals("monto_ls8")) {
				if (("647").indexOf(cod_mens) >= 0) {
					cod_campo = "LS8";
				}
			} else if (des_camp.equals("monto_cvl")) {
				if (("648.649").indexOf(cod_mens) >= 0) {
					cod_campo = "CVL";
				}
			} else if (des_camp.equals("rechazo_cwc")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWC";
				}
			} else if (des_camp.equals("rechazo_cwd")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWD";
				}
			} else if (des_camp.equals("rechazo_cwe")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWE";
				}
			} else if (des_camp.equals("rechazo_cwf")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWF";
				}
			} else if (des_camp.equals("rechazo_cwg")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWG";
				}
			} else if (des_camp.equals("rechazo_cwh")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWH";
				}
			} else if (des_camp.equals("rechazo_cwi")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWI";
				}
			} else if (des_camp.equals("rechazo_cwj")) {
				if (("630.633.636.639").indexOf(cod_mens) >= 0) {
					cod_campo = "CWJ";
				}
			}

		} catch (Exception ex) {
			System.out.println("Problemas en metodo getNombreCampo()->" + ex.getMessage());
			ex.printStackTrace();
		}
		return cod_campo;
	}

	/**
	 * Retorna un String en que los dos primeros caracteres son el estado y el resto
	 * es la descripción. param pool Pool de conexion a la base de datos. param
	 * cod_mens Codigo del mensaje.
	 * 
	 * @return String, Código y descripción de la operacion en transito de un
	 *         mensaje Carta Resguardo.
	 */
	public static String getOperacion(ConnectDB pool, String cod_mens) {
		String cod_oper = "";
		String des_oper = "";
		if (("630.633.636.639").indexOf(cod_mens) >= 0)
			cod_oper = "01";
		else if (cod_mens.equals("642"))
			cod_oper = "05";
		else if (cod_mens.equals("643"))
			cod_oper = "06";
		else if (("631.634.637.640").indexOf(cod_mens) >= 0)
			cod_oper = "07";
		else if (("632.635.638.641").indexOf(cod_mens) >= 0)
			cod_oper = "08";
		else if (cod_mens.equals("644"))
			cod_oper = "09";
		else if (cod_mens.equals("645"))
			cod_oper = "10";
		else if (cod_mens.equals("647"))
			cod_oper = "11";
		else if (cod_mens.equals("648"))
			cod_oper = "12";
		else if (cod_mens.equals("649"))
			cod_oper = "14";

		CallableStatement oCStat = null;
		ResultSet oRs = null;
		Vector paramValue = new Vector(1);
		Vector paramType = new Vector(1);
		int return_value = 0;

		try {
			paramValue.add("CR");
			paramType.add("s");
			paramValue.add(cod_oper);
			paramType.add("s");
			oCStat = pool.callSP("sp_cons_desc_det", paramValue, paramType);
			oRs = oCStat.getResultSet();
			if (oRs.next())
				des_oper = oRs.getString("des_desc");
			return_value = oCStat.getInt(1);

			oRs.close();
			oCStat.close();
			pool.closeConnection();

			if (return_value == -1)
				return (cod_oper + "ERROR");
		} catch (Exception e) {
			try {
				oRs.close();
			} catch (Exception exSp) {
			}
			try {
				oCStat.close();
			} catch (Exception exSp) {
			}
			try {
				pool.closeConnection();
			} catch (Exception exSp) {
			}
		}
		return (cod_oper + des_oper);
	}
	// Metodo principal para pruebas
	/*
	 * public static void main(String args[]) { String m_des_oper = "";
	 * //Descripción del estado del mensaje en seguimiento String m_cod_oper = "";
	 * //Código del estado del mensaje en seguimiento ConnectDB pool = null; try {
	 * pool = new ConnectDB("paramPool.txt"); }catch (Exception ex) { try {
	 * pool.closeConnection();}catch (Exception exDC) {} } String cod_mens[] =
	 * {"630","631","632","633","634","635","636","637","638","639","640","641",
	 * "642","643","644","645","646","647","648"}; String des_camp[] =
	 * {"rut_deud","nom_comp","fec_y_nse"}; for (int i=0; i<cod_mens.length; i++) {
	 * m_des_oper = getOperacion(pool, cod_mens[i]); m_cod_oper =
	 * m_des_oper.substring(0,2); m_des_oper = m_des_oper.substring(2);
	 * System.out.println("m_des_oper = ["+m_des_oper+"]");
	 * System.out.println("m_cod_oper = ["+m_cod_oper+"]"); for (int j=0;
	 * j<des_camp.length; j++)
	 * System.out.println("getNombreCampo("+cod_mens[i]+","+des_camp[j]+") = ["
	 * +getNombreCampo(cod_mens[i], des_camp[j])+"]");
	 * System.out.println("******************************************************");
	 * } try{ pool.closeConnection();} catch(Exception e ){} System.exit(0); }
	 */
}
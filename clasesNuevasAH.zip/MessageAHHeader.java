package cl.sinacofi.ah;

import cl.sinacofi.db.ConnectDB;
import cl.sinacofi.ah.MessageAH;
import cl.sinacofi.mensaje.MensajeRecibido;

/**
 * @author  Marco Ugarte C.
 * @date    06-09-2023
 * @desc    Clase encargada de realizar operaciones sobre header.
 * @version 1.0
 *
**/
public class MessageAHHeader implements MessageAH {

	private String m_cod_mens = ""; //Código del mensaje
	private String m_cod_tido = ""; //Código del Tid origen
	  private String m_cod_tidd = ""; //C�digo del Tid destino
	  private String m_num_nnse = ""; //N�mero nsr de envio del mensaje CR
	  private String m_fec_nnse = ""; //Fecha nsr de envio del mensaje CR
	  private String m_hor_nnse = ""; //Hora nsr de envio del mensaje CR
	  private String m_num_rosn = ""; //N�mero osn del mensaje recibido
	  private String m_fec_rosn = ""; //Fecha osn del mensaje recibido
	  private String m_hor_rosn = ""; //Hora osn del mensaje recibido
	  private String m_rut_vend = ""; //Rut Vendedor
	  private String m_nom_vend = ""; //Nombre Vendedor
	  private String m_rut_comp = ""; //Rut comprador
	  private String m_nom_comp = ""; //Nombre comprador
	  private String m_rut_deud = ""; //Rut deudor
	  private String m_nom_deud = ""; //Nombre deudor
	  private String x_txt_mens = ""; //Texto del mensaje recibido
	  private boolean m_estado = false;  //Indica si hay algun error en el constructor
	  private String m_cod_inte = ""; //C�digo de Operaci�n Interno
	  private String x_cod_cmpc = ""; //C�digo del campo en que se encuentra el C�digo de Operaci�n Interno
	  private String m_cod_oper = ""; //C�digo campo tipo de operaci�n
	  // Nuevos registros
	  private String m_region_origen  = ""; //Region de origen de la CR
	  private String m_comuna_origen  = ""; //Comuna de origen de la CR
	  private String m_region_destino = ""; //Region de destino de la CR
	  private String m_comuna_destino = ""; //Comuna de origen de la CR
	  private String m_monto_CSD = ""; //Monto del campo CSD
	  private String m_monto_CSF = ""; //Monto del campo CSF
	  private String m_monto_CSK = ""; //Monto del campo CSK
	  private String m_monto_CSO = ""; //Monto del campo CSO
	  private String m_monto_CUC = ""; //Monto del campo CUC
	  private String m_monto_CVR = ""; //Monto del campo CVR
	  private String m_monto_CVS = ""; //Monto del campo CVS
	  private String m_monto_CVT = ""; //Monto del campo CVT
	  private String m_monto_CVU = ""; //Monto del campo CVU
	  private String m_monto_CVZ = ""; //Monto del campo CUZ
	  private String m_monto_CW1 = ""; //Monto del campo CW1
	  private String m_monto_LS8 = ""; //Monto del campo LS8
	  private String m_monto_CVL = ""; //Monto del campo CVL
	  private String x_cod_oper = ""; //Valor del campo tipo de operacion
	  private String motivoRech = ""; //Motivo del rechazo
	
	public boolean ingRegistro(ConnectDB pool) {
		OpTblSeguimientoAH ots = new OpTblSeguimientoAH(m_cod_tido, m_cod_tidd, m_fec_nnse, m_hor_nnse, m_num_nnse,
                m_fec_rosn, m_hor_rosn, m_num_rosn, m_cod_inte, m_rut_vend, 
                m_nom_vend, m_rut_comp, m_nom_comp, m_rut_deud, m_nom_deud, 
                m_cod_oper, m_region_origen, m_comuna_origen, m_region_destino,
                m_comuna_destino, m_monto_CSD, m_monto_CSF, m_monto_CSK, m_monto_CSO,
                m_monto_CUC, m_monto_CVR, m_monto_CVS, m_monto_CVT, m_monto_CVU,
                m_monto_CVZ, m_monto_CW1, m_monto_LS8, m_monto_CVL, motivoRech);
return ots.ingRecepcion(pool);
	}

	
	public boolean esAH() {
		 if (("630.633.636.639").indexOf(m_cod_mens)>=0)
		      return true;
		    else
		      return false;

}
}